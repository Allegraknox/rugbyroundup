//This file keeps track of the hero properties, like texture, speed etc.
//It also keeps track of the ball population rate and fall rate.
//It also keeps track of the children population rate and running path complexity.

var level1 = {
    //ball info
    numBalls: 10,
    rateOfFall: .4,
    populationRate: 50,

    //child info
    rateOfBirth: 1,
    childSpeed : .15,
    pathLength: 70,
    pathComplexity: 2,
    numKids: 2,

    //hero info
    heroSpeed: 1,
    jerseyNum: 0,
    skin: Math.random()*3
}

// var level2 = {
//ball info
// rateOfFall: 0.6,
// populationRate: 20,
//
// //child info
// rateOfBirth: 3,
// pathComplexity: 3
// }
//
// var level3 = {
//ball info
// rateOfFall: 0.8,
// populationRate: 30,
//
// //child info
// rateOfBirth: 3,
// pathComplexity: 4
// }
