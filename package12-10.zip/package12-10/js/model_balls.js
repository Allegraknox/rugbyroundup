function createBall() {
  var ballModel = new THREE.Object3D();
  var ball = new THREE.Mesh(new THREE.SphereGeometry(1,32,32),
                            palatte.leather);
  ball.scale.x = 1.5;
  ballModel.add(ball);
  return ballModel;
}


function populateBalls(number, populationRate){
  var balls = [];
  for(var i = 0; i < number; i++){
    var ball = createBall();
    var random = Math.random();
    var randpos = Math.random();
    if (random < .5){
    	ball.position.x = Math.random() * 70;
      if(random <.25){
    	 ball.position.z = Math.random()*75;
      }
      else {
        ball.position.z = Math.random()*-45;
      }
    }
    else{
    	ball.position.x = Math.random()* -70;
      if(random < .75){
        ball.position.z = Math.random()* -45;
      }
      else{
        ball.position.z = Math.random()*75;
      }
    }
    ball.rotation.z = -Math.PI/4;
  	ball.position.y = 90 + populationRate*i;

    balls.push(ball);
  }
 return balls;
}
