
var childFell = false;

function intersect(a, b) {

	var bbox1 = new THREE.Box3().setFromObject(a);
	var bbox2 = new THREE.Box3().setFromObject(b);

	var bounds1 = {
    xMin: bbox1.min.x,
    xMax: bbox1.max.x,
    yMin: bbox1.min.y,
    yMax: bbox1.max.y,
    zMin: bbox1.min.z,
    zMax: bbox1.max.z,
  };

	var bounds2 = {
    xMin: bbox2.min.x,
    xMax: bbox2.max.x,
    yMin: bbox2.min.y,
    yMax: bbox2.max.y,
    zMin: bbox2.min.z,
    zMax: bbox2.max.z,
  };



	var collision = ( bounds1.xMin <= bounds2.xMax && bounds1.xMax >= bounds2.xMin ) &&
	         ( bounds1.yMin <= bounds2.yMax && bounds1.yMax >= bounds2.yMin) &&
	         ( bounds1.zMin <= bounds2.zMax && bounds1.zMax >= bounds2.zMin);

  return collision;
}

function addChildCollisioObject(child){
	children.push(child);
}

function addBallCollisionObject(ballsToAdd){
	for(var j=0; j<ballsToAdd.length; j++){
		balls[j] = ballsToAdd[j];
	}
//	console.log('balls length: ' + balls.length);
}

function checkCollisionChild(hero, children){

	var collision = false;
	for (var i = 0; i<children.length ; i++){

		collision = intersect(hero, children[i]);
		if(collision){
			handleChildCollision(hero, children[i], i);
			break;
		}
	}

			//need a fuinction to make child position move in regards to hero pushing
				//1- check hero position in relation to child
				//have child move +/- x and +/- z
}
function checkCollisionBalls(hero, balls){
	var collision = false;
	for (var i = 0; i<balls.length ; i++){

		collision = intersect(hero, balls[i]);

		if(collision){
			handleBallCollision(balls[i]);
			break;
		}
	}
}

function checkCollisionBallChild(balls, child){
	var collision = false;
	for (var i = 0; i<balls.length ; i++){

		collision = intersect(child, balls[i]);

		if(collision){
			handleBallChildCollision(child);
			stopChildren(child, i);
			break;
		}
	}


}

function handleBallChildCollision(child, index){
		//updateScore(+1);
		child.rotation.z = Math.PI/2;
		stopChildren(child, index);



}


function handleBallCollision(ball){
	//ball.dispose(); //need to implement buffer geometry to activate
	ball.position.y = 1000;
	//updateScore(-1);
}

function handleChildCollision(hero, child, index){

	var bumpSize = 3;

	var xmin = -75 +bumpSize;
  var xmax = 75 + bumpSize;
	var zmin = -45+bumpSize;
  var zmax = 72+bumpSize;
	changeXRoute(index);
	changeZRoute(index);




	if(hero.position.x < child.position.x){
		if(child.position.x < xmax)
			child.position.x += bumpSize;

	}
	if(hero.position.x > child.position.x){
		if(child.position.x > xmin)
		child.position.x -= bumpSize;
	}
	if(hero.position.z < child.position.z){
		if(child.position.z < zmax)
		child.position.z += bumpSize;
	}
	if(hero.position.z > child.position.z)
		if(child.position.z > zmin){
		child.position.z -=bumpSize;
	}

}

function checkCollisions(hero, balls, children, threadNum){
	checkCollisionBalls(hero, balls);
	checkCollisionChild(hero, children);
	for (var i=0; i<children.length; i++){
		checkCollisionBallChild(balls, children[i]);
	}
}
