var framenumber = 0;
var checked;
var character;
var threadNum = 0;
var ball;

var leg1;
var leg2;
var arm1;
var arm2;
var hair;

var count;
var speed = .05;
var speed2 = .06;

function animateHero(char, animating){
    character = char;
    checked = animating;
    threadNum++;
    if(threadNum == 1){
        leg1 = character.children[1];
        leg2 = character.children[2];
        arm1 = character.children[3];
        arm2 = character.children[4];
        hair = character.children[6];
        doFrame();
    }

}

function animateChildren(char, animating){
    leg1 = character.children[1];
    leg2 = character.children[2];
    arm1 = character.children[3];
    arm2 = character.children[4];
    hair = character.children[6];
    doFrame();
}

//--------------------------- animation support -----------------------------------

/* This function runs the animation by calling updateForFrame().
* Finally, it arranges for itself to be called again to do the next frame.  When the
* value of animating is set to false, this function does not schedule the next frame,
* so the animation stops.
*/
var framenumber = 0;
function doFrame() {
  controls.update();
   if (checked){
      updateForFrame();
      framenumber++;
    }
   requestAnimationFrame(doFrame);
}

function updateForFrame(leg1, leg2, arm1, arm2) {
   //walking animation
   count = framenumber%60
      if(count < 15){
          leg1.rotation.x -= speed;
          leg2.rotation.x += speed;
          arm1.rotation.x += speed2;
          arm2.rotation.x -= speed2;
          hair.children[0].position.y += .004;
          hair.children[1].position.y += .003;
          hair.children[2].position.y += .002;

      }
      else if(count < 30){
         leg1.rotation.x += speed;
         leg2.rotation.x -= speed;
         arm1.rotation.x -= speed2;
         arm2.rotation.x += speed2;
         hair.children[0].position.y -= .004;
         hair.children[1].position.y -= .003;
         hair.children[2].position.y -= .002;
      }
      else if (count < 45){
         leg1.rotation.x += speed;
         leg2.rotation.x -= speed;
         arm1.rotation.x -= speed2;
         arm2.rotation.x += speed2;
         hair.children[0].position.y += .004;
         hair.children[1].position.y += .003;
         hair.children[2].position.y += .002;
      }
      else{
         leg1.rotation.x -= speed;
         leg2.rotation.x += speed;
         arm1.rotation.x += speed2;
         arm2.rotation.x -= speed2;
         hair.children[0].position.y -= .004;
         hair.children[1].position.y -= .003;
         hair.children[2].position.y -= .002;

   }
}
