//This file keeps track of the hero properties, like texture, speed etc.
//It also keeps track of the ball population rate and fall rate.
//It also keeps track of the children population rate and running path complexity.

var level1 = {
    //ball info
    numBalls: 1,
    rateOfFall: .4,
    populationRate: 30,

    //child info
    childSpeed : .15,
    pathLength: 10,
    pathComplexity: 2,
    numKids: 2,

    //hero info
    heroSpeed: 1,
}

var level2 = {
    //ball info
    numBalls: 3,
    rateOfFall: .4,
    populationRate: 30,

    //child info
    childSpeed : .15,
    pathLength: 70,
    pathComplexity: 2,
    numKids: 4,

    //hero info
    heroSpeed: 1,
}

var level3 = {
    //ball info
    numBalls: 4,
    rateOfFall: .4,
    populationRate: 30,

    //child info
    childSpeed : .15,
    pathLength: 70,
    pathComplexity: 2,
    numKids: 6,

    //hero info
    heroSpeed: 1,
}
