function pause(){
  if(titleShowing == false){
    var pauseScreen = document.getElementById("pauseScreen");
    paused = !paused;
    if(paused){
        pauseScreen.innerHTML = "<h1>GAME PAUSED</h1><h5>Press spacebar to unpause</h5><div id='innerPause'></div>";
        var innerPause = document.getElementById('innerPause');
        innerPause.innerHTML = "<p id='returnTitle'>Return to title screen</p><p id='restartLvl'>Restart level</p>";
        document.getElementById('returnTitle').addEventListener("click", showTitleScreen), false;
        document.getElementById('restartLvl').addEventListener("click", restartLevel, false);
    }
    else{
        pauseScreen.innerHTML = "";
    }
  }
}
var titleShowing;

function showTitleScreen(){
  titleShowing = true;
  paused = true;
  document.getElementById("scoreboard").innerHTML = "";
  document.getElementById("pauseScreen").innerHTML = "";
  var titleScreenWrapper = document.getElementById("startScreenWrapper");
  titleScreenWrapper.innerHTML = "<div id='startScreen'></div>";
  var titleScreen = document.getElementById("startScreen");
  var titleText = "<h1 id='title'>RUGBY ROUNDUP</h1><h2>Catch the balls and make sure the children don't get hit!</h2>"
  titleText += "<h3>Use the arrow keys to move, spacebar to pause.</h3>";
  titleText += "<p id = 'chooseChar'>Pick a character to start:</p>";
  titleText += "<div id='char1' class='profPic'></div><div id='char2' class='profPic'></div><div id='char3' class='profPic'></div>";
  titleText += "<div id='char4' class='profPic'></div><div id='char5' class='profPic'></div><div id='char6' class='profPic'></div><div id='char7' class='profPic'></div>";

  titleScreen.innerHTML = titleText;
  var char1 = document.getElementById('char1');
  var char2 = document.getElementById('char2');
  var char3 = document.getElementById('char3');
  var char4 = document.getElementById('char4');
  var char5 = document.getElementById('char5');
  var char6 = document.getElementById('char6');
  var char7 = document.getElementById('char7');

  char1.innerHTML = '<img src= "../images/allegra.png">';
  char2.innerHTML = '<img src= "../images/emma.png">';
  char3.innerHTML = '<img src= "../images/val.png">';
  char4.innerHTML = '<img src= "../images/nicole.png">';
  char5.innerHTML = '<img src= "../images/tubes.png">';
  char6.innerHTML = '<img src= "../images/shelley.png">';
  char7.innerHTML = '<img src= "../images/allegra.png">';

  char1.addEventListener("click", function(){startGame("allegra");}, false);
  char2.addEventListener("click", function(){startGame("emma");}, false);
  char3.addEventListener("click", function(){startGame("val");}, false);
  char4.addEventListener("click", function(){startGame("nicole");}, false);
  char5.addEventListener("click", function(){startGame("tubes");}, false);
  char6.addEventListener("click", function(){startGame("shelley");}, false);
  char7.addEventListener("click", function(){startGame("anna");}, false);
}

function restartLevel(){
  //reset scoreboard
  currentScore = 0;
  ballsLeft = currentLevel.numBalls;
  scoreboard.innerHTML = "<h1>RUGBY ROUNDUP</h1>\n<h2>Balls remaining: "+ ballsLeft+"</h2>\n<h3>Score: "+ currentScore;

  //repopulate balls
  for( var i =0; i< Balls.length; i++){
    scene.remove(Balls[i].ball);
    scene.remove(Balls[i].shadow);
  }
  Balls = null;
  Balls= populateBalls(currentLevel.numBalls, currentLevel.populationRate);

  //resume level
  paused = false;
  pauseScreen.innerHTML = "";
}

var playerSkin;
var playerHair;

function startGame(name){
  switch( name ) {
    case "allegra":
    playerSkin = palatte.skin[LIGHT];
    playerHair = palatte.hair[BROWN];
    break;
    case "emma":
    playerSkin = palatte.skin[MEDIUM];
    playerHair = palatte.hair[BLONDE];
    break;
    case "val":
    playerSkin = palatte.skin[LIGHT];
    playerHair = palatte.hair[GINGER];
    break;
    case "nicole":
    playerSkin = palatte.skin[MEDIUM];
    playerHair = palatte.hair[BROWN];
    break;
    case "tubes":
    playerSkin = palatte.skin[LIGHT];
    playerHair = palatte.hair[BLONDE];
    break;
    case "shelley":
    playerSkin = palatte.skin[MEDIUM];
    playerHair = palatte.hair[DARK];
    break;
    case "anna":
    playerSkin = palatte.skin[LIGHT];
    playerHair = palatte.hair[BROWN];
    break;
  }

  document.getElementById("startScreen").innerHTML = "";
  document.getElementById("startScreenWrapper").innerHTML = "";
  titleShowing = false;
  restartLevel();
}
